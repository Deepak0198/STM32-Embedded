#include <stdint.h>
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include "stm32f446xx.h"

#define MAX_BUFFER_SIZE 100
#define NUM_VALUES 10

// Function Prototypes
void SysClockConfig(void);
void UART2_Init(void);
void UART2_SendChar(uint8_t c);
void UART2_SendString(char *string);
uint8_t UART2_GetChar(void);
void DAC_Init(void);
void Button_Init(void);
void LED_Init(void);
void Timer2_PWM_Init(void);
void EXTI15_10_IRQHandler(void);
uint32_t factorial(uint32_t num);
uint32_t nCr(uint32_t n, uint32_t r);

volatile uint8_t buttonPressed = 0;
volatile uint8_t incrementDAC = 0;
volatile uint8_t exitUtility = 0;
volatile uint32_t dacValueIndex = 0;
uint16_t dac_values[NUM_VALUES] = { 0,2850, 2906, 2962, 3018, 3075, 3131, 3187, 3243, 3300}; // Adjusted DAC values

// System Clock Configuration
void SysClockConfig(void) {
	RCC->CR |= RCC_CR_HSEON;
	while (!(RCC->CR & RCC_CR_HSERDY))
		;
	RCC->APB1ENR |= RCC_APB1ENR_PWREN;
	PWR->CR |= PWR_CR_VOS;
	FLASH->ACR = FLASH_ACR_ICEN | FLASH_ACR_DCEN | FLASH_ACR_PRFTEN
			| FLASH_ACR_LATENCY_5WS;
	RCC->CFGR |= RCC_CFGR_HPRE_DIV1;
	RCC->CFGR |= RCC_CFGR_PPRE1_DIV4;
	RCC->CFGR |= RCC_CFGR_PPRE2_DIV2;
	RCC->PLLCFGR = (4 << 0) | (180 << 6) | (0 << 16) | (RCC_PLLCFGR_PLLSRC_HSE);
	RCC->CR |= RCC_CR_PLLON;
	while (!(RCC->CR & RCC_CR_PLLRDY))
		;
	RCC->CFGR |= RCC_CFGR_SW_PLL;
	while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL)
		;
}

// UART Configuration
void UART2_Init(void) {
	RCC->APB1ENR |= (1 << 17);  // Enable UART2 clock
	RCC->AHB1ENR |= (1 << 0);   // Enable GPIOA clock

	GPIOA->MODER |= (2 << 4);   // Alternate function mode for PA2
	GPIOA->MODER |= (2 << 6);   // Alternate function mode for PA3
	GPIOA->AFR[0] |= (7 << 8);  // AF7 for UART2 on PA2
	GPIOA->AFR[0] |= (7 << 12); // AF7 for UART2 on PA3

	USART2->BRR = (7 << 0) | (24 << 4); // 115200 baud @ 16MHz/
	USART2->CR1 = 0x00U;
	USART2->CR1 |= (1 << 13);   // Enable USART2
	USART2->CR1 |= (1 << 2);    // Enable RX
	USART2->CR1 |= (1 << 3);    // Enable TX
	USART2->CR1 |= (1 << 5);    // Enable RXNE interrupt

	NVIC_EnableIRQ(USART2_IRQn);
}

void USART2_IRQHandler(void) {
	if (USART2->SR & (1 << 5)) {
		uint8_t receivedChar = USART2->DR;

		// Process received character based on menu options
		static char buffer[MAX_BUFFER_SIZE];
		static uint8_t index = 0;

		if (receivedChar != '\r') {
			buffer[index++] = receivedChar;
		} else {
			buffer[index] = '\0';
			index = 0;

			if (buffer[0] == '1') {
				UART2_SendString("\r\nEnter n: ");
				char n_str[5], r_str[5];
				uint8_t i = 0;

				// Read the 'n' value from UART
				while (1) {
					uint8_t ch = UART2_GetChar();
					if (ch == '\r') {
						n_str[i] = '\0';
						break;
					}
					n_str[i++] = ch;
					UART2_SendChar(ch); // Echo the received character back to the terminal
				}

				uint32_t n = atoi(n_str);
				UART2_SendString("\r\nEnter r: ");
				i = 0;

				// Read the 'r' value from UART
				while (1) {
					uint8_t ch = UART2_GetChar();
					if (ch == '\r') {
						r_str[i] = '\0';
						break;
					}
					r_str[i++] = ch;
					UART2_SendChar(ch); // Echo the received character back to the terminal
				}

				uint32_t r = atoi(r_str);
				uint32_t result = nCr(n, r);
				char result_str[20];
				sprintf(result_str, "\r\nResult: %lu\r\n", result);
				UART2_SendString(result_str);
			} else if (buffer[0] == '2') {
				incrementDAC = 1;
				DAC->DHR12R1 = dac_values[dacValueIndex];
				DAC->SWTRIGR |= (1 << 0); // Trigger the DAC to update the value
				UART2_SendString("\r\nDAC output started.\n");
			} else if (buffer[0] == '3') {
				exitUtility = 1;
				UART2_SendString("\r\nExiting utility.\n");
			} else {
				UART2_SendString("\r\nInvalid option.\n");
			}
			UART2_SendString("\rEnter option: ");
		}
	}
}

void UART2_SendChar(uint8_t c) {
	while (!(USART2->SR & (1 << 7)))
		;
	USART2->DR = c;
}

void UART2_SendString(char *string) {
	while (*string) {
		UART2_SendChar(*string++);
	}
}

uint8_t UART2_GetChar(void) {
	while (!(USART2->SR & (1 << 5)))
		;
	return USART2->DR;
}

// DAC Initialization
void DAC_Init(void) {
	RCC->APB1ENR |= (1 << 29);  // Enable DAC clock
	RCC->AHB1ENR |= (1 << 0);   // Enable GPIOA clock

	GPIOA->MODER |= (3 << 8);   // Set PA4 to analog mode

	DAC->CR |= (1 << 0);        // Enable DAC channel 1
}

// LED Initialization
void LED_Init(void) {
	RCC->AHB1ENR |= (1 << 0);   // Enable GPIOA clock
	GPIOA->MODER |= (2 << 10);  // Set PA5 to alternate function mode
	GPIOA->AFR[0] |= (1 << 20); // AF1 for PA5 (TIM2_CH1)
}

// Timer2 PWM Initialization
void Timer2_PWM_Init(void) {
	RCC->APB1ENR |= RCC_APB1ENR_TIM2EN; // Enable TIM2 clock

	TIM2->PSC = 160 - 1;    // Prescaler (16 MHz / 160 = 100 kHz)
	TIM2->ARR = 1000 - 1; // Auto-reload register (100 kHz / 1000 = 100 Hz PWM frequency)
	TIM2->CCMR1 |= (6 << 4); // PWM mode 1 on CH1
	TIM2->CCER |= TIM_CCER_CC1E; // Enable capture/compare 1 output
	TIM2->CCR1 = 0;         // Initial duty cycle (0%)

	TIM2->CR1 |= TIM_CR1_CEN; // Enable TIM2
}

// Button Initialization
void Button_Init(void) {
	RCC->AHB1ENR |= (1 << 2);   // Enable GPIOC clock
	RCC->APB2ENR |= (1 << 14);  // Enable SYSCFG clock

	GPIOC->MODER &= ~(3 << 26); // Set PC13 to input mode
	GPIOC->PUPDR |= (2 << 26);  // Pull-down for PC13

	SYSCFG->EXTICR[3] &= ~(15 << 4); // Configure PC13 as EXTI13
	SYSCFG->EXTICR[3] |= (2 << 4);   // Configure PC13 as EXTI13
	EXTI->IMR |= (1 << 13);    // Unmask EXTI13
	EXTI->RTSR |= (1 << 13);   // Rising edge trigger

	NVIC_EnableIRQ(EXTI15_10_IRQn); // Enable EXTI15_10 interrupt
}

void EXTI15_10_IRQHandler(void) {
	if (EXTI->PR & (1 << 13)) {
		EXTI->PR |= (1 << 13);  // Clear pending bit
		if (incrementDAC) {
			dacValueIndex = (dacValueIndex + 1) % NUM_VALUES;
			DAC->DHR12R1 = dac_values[dacValueIndex];
			DAC->SWTRIGR |= (1 << 0); // Trigger the DAC to update the value
			TIM2->CCR1 = (dac_values[dacValueIndex] * 1000) / 4095; // Update PWM duty cycle
		}
	}
}

// nCr Calculation
uint32_t factorial(uint32_t num) {
	if (num == 0)
		return 1;
	uint32_t result = 1;
	for (uint32_t i = 1; i <= num; ++i) {
		result *= i;
	}
	return result;
}

uint32_t nCr(uint32_t n, uint32_t r) {
	return factorial(n) / (factorial(r) * factorial(n - r));
}

// Main Function
int main(void) {
	SysClockConfig();
	UART2_Init();
	DAC_Init();
	Button_Init();
	LED_Init();
	Timer2_PWM_Init();

	UART2_SendString("\rMenu:\n");
	UART2_SendString("\r1. Print nCr value\r\n");
	UART2_SendString("\r2. Start outputting DAC values\r\n");
	UART2_SendString("\r3. Exit utility\r\n");
	UART2_SendString("\rEnter option: ");

	while (!exitUtility) {
		// Main loop does nothing, interrupt handlers handle everything
	}
}
