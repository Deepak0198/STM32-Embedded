/*
 * main.h
 *
 *  Created on: Jul 27, 2024
 *      Author: HP
 */

#ifndef MAIN_H_
#define MAIN_H_

#include <stdint.h>

// Function Prototypes
void SysClockConfig(void);
void Uart2Config(void);
void UART2_SendChar(uint8_t c);
void UART2_SendString(char *string);
uint8_t UART2_GetChar(void);
void TIM6Config(void);
void Delay_us(uint16_t us);
void Delay_ms(uint16_t ms);
void LED_Init(void);
void LED_Blink(uint16_t delay);
void PWM_Init(void);
void Set_PWM_Intensity(uint8_t intensity);
void Button_Init(void);
uint8_t Button_Pressed(void);

#endif /* MAIN_H_ */
